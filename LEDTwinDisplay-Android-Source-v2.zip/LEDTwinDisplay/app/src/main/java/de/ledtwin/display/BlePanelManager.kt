package de.ledtwin.display

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

/**
 * Two independent BLE GATT links. The panel protocol uses the iPixel/B.K. Light
 * service family. Device firmware can differ; this is a prototype transport.
 */
class BlePanelManager(private val context: Context) {
    companion object {
        val SERVICE: UUID = UUID.fromString("0000fa01-0000-1000-8000-00805f9b34fb")
        val WRITE: UUID = UUID.fromString("0000fa02-0000-1000-8000-00805f9b34fb")
        val NOTIFY: UUID = UUID.fromString("0000fa03-0000-1000-8000-00805f9b34fb")
    }

    data class Device(val name: String, val address: String, val rssi: Int)
    private val adapter = (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private val gattMap = ConcurrentHashMap<String, BluetoothGatt>()
    private val writeChars = ConcurrentHashMap<String, BluetoothGattCharacteristic>()
    private val scanDevices = ConcurrentHashMap<String, Device>()

    @SuppressLint("MissingPermission")
    suspend fun scan(seconds: Long = 8): List<Device> = withContext(Dispatchers.Main) {
        scanDevices.clear()
        val scanner = adapter.bluetoothLeScanner
        val callback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val d = result.device
                scanDevices[d.address] = Device(d.name ?: result.scanRecord?.deviceName ?: "LED panel",
                    d.address, result.rssi)
            }
        }
        scanner.startScan(null, ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), callback)
        delay(seconds * 1000)
        scanner.stopScan(callback)
        scanDevices.values.sortedByDescending { it.rssi }
    }

    @SuppressLint("MissingPermission")
    suspend fun connect(address: String): Boolean = withContext(Dispatchers.Main) {
        val device = adapter.getRemoteDevice(address)
        suspendCoroutine { cont ->
            var resumed = false
            val callback = object : BluetoothGattCallback() {
                override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
                    if (newState == BluetoothProfile.STATE_CONNECTED) {
                        gatt.discoverServices()
                    } else if (!resumed) {
                        resumed = true
                        cont.resume(false)
                    }
                }
                override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
                    val service = gatt.getService(SERVICE)
                    val characteristic = service?.getCharacteristic(WRITE)
                    if (status == BluetoothGatt.GATT_SUCCESS && characteristic != null) {
                        gattMap[address] = gatt
                        writeChars[address] = characteristic
                        if (!resumed) { resumed = true; cont.resume(true) }
                    } else if (!resumed) {
                        resumed = true; cont.resume(false)
                    }
                }
            }
            device.connectGatt(context, false, callback, BluetoothDevice.TRANSPORT_LE)
        }
    }

    @SuppressLint("MissingPermission")
    suspend fun sendFrame(address: String, rgb: ByteArray): Boolean {
        val gatt = gattMap[address] ?: return false
        val ch = writeChars[address] ?: return false
        val bytes = FrameRenderer.packet(rgb)
        val mtuPayload = 180 // conservative chunk size; actual negotiated MTU may vary
        return withContext(Dispatchers.IO) {
            var offset = 0
            while (offset < bytes.size) {
                val end = minOf(offset + mtuPayload, bytes.size)
                val chunk = bytes.copyOfRange(offset, end)
                val ok = if (Build.VERSION.SDK_INT >= 33) {
                    gatt.writeCharacteristic(ch, chunk, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE) == BluetoothStatusCodes.SUCCESS
                } else {
                    @Suppress("DEPRECATION")
                    ch.value = chunk
                    @Suppress("DEPRECATION")
                    ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                    @Suppress("DEPRECATION")
                    gatt.writeCharacteristic(ch)
                }
                if (!ok) return@withContext false
                offset = end
                delay(12)
            }
            true
        }
    }

    @SuppressLint("MissingPermission")
    fun disconnect(address: String) {
        gattMap.remove(address)?.disconnect()
        gattMap.remove(address)?.close()
        writeChars.remove(address)
    }
}
