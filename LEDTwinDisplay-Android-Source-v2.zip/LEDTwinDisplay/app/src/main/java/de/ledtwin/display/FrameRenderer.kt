package de.ledtwin.display

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import kotlin.math.max

/**
 * Produces one 128x16 RGB framebuffer and splits it into two 64x16 panels.
 * The display transport currently uses the documented B.K. Light raw-frame
 * command format. Confirm compatibility on the exact firmware before use.
 */
object FrameRenderer {
    const val FULL_WIDTH = 128
    const val HEIGHT = 16
    const val PANEL_WIDTH = 64

    fun renderText(text: String, color: Int, offsetX: Int = 0): Bitmap {
        val bitmap = Bitmap.createBitmap(FULL_WIDTH, HEIGHT, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.BLACK)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            textSize = 13.5f
            typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        }
        val baseline = 13.0f
        canvas.drawText(text, offsetX.toFloat(), baseline, paint)
        return bitmap
    }

    fun split(bitmap: Bitmap): Pair<ByteArray, ByteArray> {
        require(bitmap.width == FULL_WIDTH && bitmap.height == HEIGHT)
        return encode(bitmap, 0) to encode(bitmap, PANEL_WIDTH)
    }

    private fun encode(bitmap: Bitmap, xStart: Int): ByteArray {
        val out = ByteArray(PANEL_WIDTH * HEIGHT * 3)
        var i = 0
        for (y in 0 until HEIGHT) {
            for (x in 0 until PANEL_WIDTH) {
                val c = bitmap.getPixel(xStart + x, y)
                out[i++] = Color.red(c).toByte()
                out[i++] = Color.green(c).toByte()
                out[i++] = Color.blue(c).toByte()
            }
        }
        return out
    }

    fun packet(frame: ByteArray): ByteArray {
        require(frame.size == 64 * 16 * 3)
        val header = byteArrayOf(0x09, 0x0C, 0, 0, 0, 0, 0x0C, 0, 0)
        return header + frame
    }
}
