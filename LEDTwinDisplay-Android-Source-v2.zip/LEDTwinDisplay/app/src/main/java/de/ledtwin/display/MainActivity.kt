package de.ledtwin.display

import android.Manifest
import android.graphics.Color as AndroidColor
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val perms = if (Build.VERSION.SDK_INT >= 31) arrayOf(
            Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT
        ) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        permissionLauncher.launch(perms)
        setContent { MaterialTheme { LedTwinApp(BlePanelManager(this)) } }
    }
}

@Composable
private fun LedTwinApp(ble: BlePanelManager) {
    val scope = rememberCoroutineScope()
    var message by remember { mutableStateOf("FEUERWEHR IM EINSATZ") }
    var color by remember { mutableStateOf(AndroidColor.RED) }
    var speed by remember { mutableFloatStateOf(1f) }
    var devices by remember { mutableStateOf(emptyList<BlePanelManager.Device>()) }
    var left by remember { mutableStateOf<String?>(null) }
    var right by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("Gotowy do skanowania") }
    var scanning by remember { mutableStateOf(false) }
    var sending by remember { mutableStateOf(false) }
    var preview by remember { mutableStateOf(FrameRenderer.renderText(message, color)) }

    fun render() { preview = FrameRenderer.renderText(message, color) }

    Scaffold(topBar = {
        TopAppBar(title = { Text("LED Twin Display") })
    }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Text("Wirtualny ekran 128 × 16", style = MaterialTheme.typography.titleMedium)
                Canvas(Modifier.fillMaxWidth().height(72.dp).background(Color.Black, RoundedCornerShape(8.dp)).padding(6.dp)) {
                    drawImage(preview.asImageBitmap())
                }
                Text("Lewa połowa → panel 1  |  prawa połowa → panel 2", fontSize = 12.sp)
            }
            item {
                OutlinedTextField(value = message, onValueChange = { message = it; render() },
                    label = { Text("Komunikat") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(AndroidColor.RED, AndroidColor.GREEN, AndroidColor.BLUE, AndroidColor.WHITE, AndroidColor.YELLOW).forEach { c ->
                        Button(onClick = { color = c; render() }, contentPadding = PaddingValues(4.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(c))) { Text("●", color = Color.Black) }
                    }
                }
                Text("Szybkość przewijania: ${speed.toInt()}")
                Slider(value = speed, onValueChange = { speed = it }, valueRange = 1f..5f)
            }
            item {
                Button(onClick = {
                    scope.launch {
                        scanning = true; status = "Skanowanie Bluetooth LE…"
                        devices = ble.scan()
                        scanning = false
                        status = "Znaleziono: ${devices.size} urządzeń"
                    }
                }, enabled = !scanning, modifier = Modifier.fillMaxWidth()) {
                    Text(if (scanning) "Skanowanie…" else "Szukaj paneli Bluetooth")
                }
                Text(status, style = MaterialTheme.typography.bodySmall)
            }
            items(devices) { d ->
                Card {
                    Column(Modifier.padding(12.dp)) {
                        Text(d.name, style = MaterialTheme.typography.titleSmall)
                        Text("${d.address}  •  RSSI ${d.rssi} dBm", style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                scope.launch { status = if (ble.connect(d.address)) "Połączono: ${d.name}" else "Błąd połączenia: ${d.name}"; left = d.address }
                            }) { Text(if (left == d.address) "Lewy ✓" else "Ustaw jako lewy") }
                            OutlinedButton(onClick = {
                                scope.launch { status = if (ble.connect(d.address)) "Połączono: ${d.name}" else "Błąd połączenia: ${d.name}"; right = d.address }
                            }) { Text(if (right == d.address) "Prawy ✓" else "Ustaw jako prawy") }
                        }
                    }
                }
            }
            item {
                Button(onClick = {
                    scope.launch {
                        if (left == null || right == null) { status = "Najpierw połącz oba panele"; return@launch }
                        sending = true
                        val halves = FrameRenderer.split(preview)
                        val a = ble.sendFrame(left!!, halves.first)
                        val b = ble.sendFrame(right!!, halves.second)
                        status = "Wysłano: lewy=$a, prawy=$b"
                        sending = false
                    }
                }, enabled = !sending, modifier = Modifier.fillMaxWidth()) {
                    Text(if (sending) "Wysyłanie…" else "Wyślij obraz na oba panele")
                }
            }
            item {
                Text("Wersja prototypowa 0.1.0", style = MaterialTheme.typography.labelSmall)
                Text("Import GIF, oś czasu animacji, edytor klatek i synchronizacja przewijania są przewidziane w następnym etapie. Najpierw trzeba potwierdzić transmisję na Twoich egzemplarzach.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
